package com.udacity.jwdnd.course1.cloudstorage.mapper;

import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CredentialMapper  {

    @Select("Select * from CREDENTIALS where credentialid = #{credentialid}")
    Credential getCredential(Integer credentialid);

    @Insert("Insert into CREDENTIALS(url,username,key,password,userid) VALUES(#{url},#{username},#{key},#{password},#{userid})")
    @Options(useGeneratedKeys = true, keyProperty = "credentialid")
    int saveCredential(Credential credential);

    @Select("Select * from CREDENTIALS where userid = #{userid}")
    List<Credential> getCredentialsByUserId(Integer userid);

    @Update("Update CREDENTIALS set url = #{url}, username = #{username},key = #{key}, password = #{password} where credentialid = #{credentialid}")
    int updateCredential(Credential credential);

    @Delete("Delete from CREDENTIALS where credentialid = #{credentialid}")
    int deleteCredential(Integer credentialid);
}
