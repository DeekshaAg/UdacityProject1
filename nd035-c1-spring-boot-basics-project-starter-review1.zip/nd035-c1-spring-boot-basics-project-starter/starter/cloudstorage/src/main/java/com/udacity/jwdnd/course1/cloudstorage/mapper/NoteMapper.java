package com.udacity.jwdnd.course1.cloudstorage.mapper;

import com.udacity.jwdnd.course1.cloudstorage.model.Note;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface NoteMapper {

    @Select("Select * from NOTES where noteid = #{noteid}")
    Note getNote(Integer noteid);

    @Insert("Insert into NOTES(notetitle, notedescription, userid) VALUES(#{notetitle},#{notedescription},#{userid})")
    @Options(useGeneratedKeys = true, keyProperty = "noteid")
    int saveNote(Note note);

    @Select("Select * from NOTES where userid = #{userid}")
    List<Note> getNotesByUserid(Integer userid);

    @Update("Update NOTES set notetitle = #{notetitle}, notedescription = #{notedescription} where noteid = #{noteid}")
    int updateNote(Note note);

    @Delete("Delete from NOTES where noteid = #{noteid}")
    int deleteNote(Integer noteid);
}
