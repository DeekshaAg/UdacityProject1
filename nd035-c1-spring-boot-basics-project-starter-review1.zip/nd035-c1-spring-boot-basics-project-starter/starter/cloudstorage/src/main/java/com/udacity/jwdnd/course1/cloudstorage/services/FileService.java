package com.udacity.jwdnd.course1.cloudstorage.services;

import com.udacity.jwdnd.course1.cloudstorage.mapper.FileMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.File;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Service
public class FileService {

    private FileMapper fileMapper;

    public FileService(FileMapper fileMapper) {
        this.fileMapper = fileMapper;
    }

    public File getFile(String filename){
        return fileMapper.getFileByFileName(filename);
    }

    public List<File> getFilesForUser(Integer userid){
        return fileMapper.getAllFilesByUserid(userid);
    }

    public int createFile(File file){
        return fileMapper.createFile(file);
    }

    public int deleteFile(Integer fileid){
        return fileMapper.deleteFile(fileid);
    }

    public boolean doesFileNameExist(String fileName, Integer userid){
        return fileMapper.getFileByName(fileName,userid) != null;
    }

    public void downloadImage() throws IOException {
        try(InputStream in = new URL("http://example.com/image.jpg").openStream()){
            Files.copy(in, Paths.get("C:/File/To/Save/To/image.jpg"));
        }
    }
}
