package com.udacity.jwdnd.course1.cloudstorage.services;

import com.udacity.jwdnd.course1.cloudstorage.mapper.CredentialMapper;
import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import com.udacity.jwdnd.course1.cloudstorage.model.CredentialView;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
public class CredentialService {

    private EncryptionService encryptionService;
    private CredentialMapper credentialMapper;

    public CredentialService(EncryptionService encryptionService, CredentialMapper credentialMapper) {
        this.encryptionService = encryptionService;
        this.credentialMapper = credentialMapper;
    }

    public int createCredential(Credential credential){
        SecureRandom random = new SecureRandom();
        byte[] key = new byte[16];
        random.nextBytes(key);
        String encodedKey = Base64.getEncoder().encodeToString(key);
        String encryptedPassword = encryptionService.encryptValue(credential.getPassword(), encodedKey);
        return credentialMapper.saveCredential(new Credential(null,credential.getUrl(),credential.getUsername(),encodedKey,encryptedPassword,credential.getUserid()));
    }

    public List<CredentialView> getCredentialsForUser(Integer userid){
        List<Credential> clist = credentialMapper.getCredentialsByUserId(userid);
        List<CredentialView> cvlist = new ArrayList<CredentialView>();
        for(Credential cred : clist){
            String decodedPassword = encryptionService.decryptValue(cred.getPassword(),cred.getKey());
            cvlist.add(new CredentialView(cred.getCredentialid(),cred.getUrl(),cred.getUsername(),cred.getKey(),decodedPassword,cred.getUserid(), cred.getPassword()));
            //cred.setPassword(decodedPassword);
        }
        return cvlist;
    }

    public int updateCredential(Credential credential){
        SecureRandom random = new SecureRandom();
        byte[] key = new byte[16];
        random.nextBytes(key);
        String encodedKey = Base64.getEncoder().encodeToString(key);
        String encryptedPassword = encryptionService.encryptValue(credential.getPassword(), encodedKey);
        credential.setKey(encodedKey);
        credential.setPassword(encryptedPassword);
        return credentialMapper.updateCredential(credential);
    }

    public int deleteCredential(Integer credentialId){
        return credentialMapper.deleteCredential(credentialId);
    }

}
