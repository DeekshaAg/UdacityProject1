package com.udacity.jwdnd.course1.cloudstorage.controller;

import com.udacity.jwdnd.course1.cloudstorage.model.Credential;
import com.udacity.jwdnd.course1.cloudstorage.model.File;
import com.udacity.jwdnd.course1.cloudstorage.model.Note;
import com.udacity.jwdnd.course1.cloudstorage.services.CredentialService;
import com.udacity.jwdnd.course1.cloudstorage.services.FileService;
import com.udacity.jwdnd.course1.cloudstorage.services.NoteService;
import com.udacity.jwdnd.course1.cloudstorage.services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.sql.rowset.serial.SerialBlob;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;


@Controller
public class HomeController {

    private UserService userService;
    private CredentialService credentialService;
    private NoteService noteService;
    private FileService fileService;

    private static final Logger LOG = LoggerFactory.getLogger(HomeController.class);

    public HomeController(CredentialService credentialService, NoteService noteService, UserService userService, FileService fileService) {
        this.credentialService = credentialService;
        this.noteService = noteService;
        this.userService = userService;
        this.fileService = fileService;
    }

    @RequestMapping(method= RequestMethod.GET, value="/home")
    public String getHomePage(@ModelAttribute Note note, @ModelAttribute Credential credential, Model model){
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            int userId = userService.getUserId(username);
            model.addAttribute("credentials", credentialService.getCredentialsForUser(userId));
            model.addAttribute("notes", noteService.getNotesForUser(userId));
            model.addAttribute("files", fileService.getFilesForUser(userId));
        }catch (Exception ex){
            return "error";
        }
        return "home";

    }

    @RequestMapping(method = RequestMethod.POST, value="/file")
    public String saveFile(@RequestParam("fileUpload")MultipartFile fileUpload, Model model) throws IOException, SQLException {
        try {
            if(fileUpload.getOriginalFilename().isEmpty()){
                model.addAttribute("fileError", "No file was selected for upload. Please select a proper file");
                model.addAttribute("successMsg", Boolean.FALSE);
                return "result";
            }

            if(fileUpload.getSize() > 10485700){
                model.addAttribute("fileError", "File size was too large");
                model.addAttribute("successMsg", Boolean.FALSE);
                return "result";
            }
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            int userId = userService.getUserId(username);

            if (fileService.doesFileNameExist(fileUpload.getOriginalFilename(), userId)) {
                model.addAttribute("fileError", "File Name already exists");
                model.addAttribute("successMsg", Boolean.FALSE);
                return "result";
            } else {
                File file = new File(null, fileUpload.getOriginalFilename(), fileUpload.getContentType(), fileUpload.getSize() + "", userId, fileUpload.getBytes());
                int noOfRows = 0;
                noOfRows = fileService.createFile(file);

                if (noOfRows <= 0) {
                    model.addAttribute("fileError", "Your file upload failed");
                    model.addAttribute("successMsg", Boolean.FALSE);
                } else {
                    model.addAttribute("successMsg", Boolean.TRUE);
                }
                return "result";
            }
        }catch (IllegalStateException e){
            return "error-500";
        }catch (Exception ex){
            return "error";
        }
    }

    @RequestMapping(method = RequestMethod.POST, value="/credential")
    public String saveCredentials(@ModelAttribute Credential credential, Model model){
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            int userId = userService.getUserId(username);
            credential.setUserid(userId);
            int noOfRows = 0;
            if (credential.getCredentialid() != null) {
                noOfRows = credentialService.updateCredential(credential);
            } else {
                noOfRows = credentialService.createCredential(credential);
            }
            if (noOfRows <= 0) {
                model.addAttribute("fileError", "Your credential changes were not saved");
                model.addAttribute("successMsg", Boolean.FALSE);
            } else {
                model.addAttribute("successMsg", Boolean.TRUE);
            }
            return "result";
        }catch (Exception e){
            return "error";
        }
    }

    @RequestMapping(method= RequestMethod.POST, value = "/note")
    public String saveNotes(@ModelAttribute Note note, Model model){
        try {
            String username = SecurityContextHolder.getContext().getAuthentication().getName();
            int userId = userService.getUserId(username);
            note.setUserid(userId);
            int noOfRows = 0;
            if (note.getNoteid() != null) {
                noOfRows = noteService.UpdateNote(note);
            } else {
                noOfRows = noteService.createNote(note);
            }
            if (noOfRows <= 0) {
                model.addAttribute("fileError", "Your notes were not saved");
                model.addAttribute("successMsg", Boolean.FALSE);
            } else {
                model.addAttribute("successMsg", Boolean.TRUE);
            }

            return "result";
        }catch (Exception e){
            return "error";
        }
    }

    @RequestMapping(method=RequestMethod.GET, value = "/downloadFile/{filename}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String filename) {
        try {

            File file = fileService.getFile(filename);

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(file.getContenttype()))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment:filename=\"" + file.getFilename() + "\"")
                    .body(new ByteArrayResource(file.getFiledata()));
        }catch (Exception e){
            return null;
        }
    }

    @RequestMapping(method = RequestMethod.DELETE, value="/deleteFile/{id}")
    public String deleteFile(@PathVariable Integer id, Model model){
        try{
            int noOfRows = fileService.deleteFile(id);
            if(noOfRows<=0){
                model.addAttribute("fileError", "Your file deletion failed");
                model.addAttribute("successMsg",Boolean.FALSE);
            }else{
                model.addAttribute("successMsg", Boolean.TRUE);
            }
            return "result";
        }catch (Exception e){
            return "error";
        }
    }


    @RequestMapping(method = RequestMethod.DELETE, value="/deleteCredential/{id}")
    public String deleteCredential(@PathVariable Integer id, Model model){
        try {
            int noOfRows = credentialService.deleteCredential(id);
            if (noOfRows <= 0) {
                model.addAttribute("fileError", "Your credential deletion failed");
                model.addAttribute("successMsg", Boolean.FALSE);
            } else {
                model.addAttribute("successMsg", Boolean.TRUE);
            }
            return "result";
        }catch (Exception e){
            return "error";
        }
    }

    @RequestMapping(method = RequestMethod.DELETE, value="/deleteNote/{id}")
    public String deleteNote(@PathVariable Integer id, Model model){
        try {
            int noOfRows = noteService.deleteNote(id);

            if (noOfRows <= 0) {
                model.addAttribute("fileError", "Your note deletion failed");
                model.addAttribute("successMsg", Boolean.FALSE);
            } else {
                model.addAttribute("successMsg", Boolean.TRUE);
            }
            return "result";
        }catch (Exception e){
            return "error";
        }
    }

}
