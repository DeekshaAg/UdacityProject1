package com.udacity.jwdnd.course1.cloudstorage.mapper;

import com.udacity.jwdnd.course1.cloudstorage.model.File;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface FileMapper {

    @Select("Select * from FILES where fileid = #{fileid}")
    File getFileById(Integer fileid);

    @Select("Select * from FILES where filename = #{filename}")
    File getFileByFileName(String filename);

    @Select("Select * from FILES where userid = #{userid}")
    List<File> getAllFilesByUserid(Integer userid);

    @Select("Select * from FILES where filename = #{filename} and userid = #{userid}")
    File getFileByName(String filename ,Integer userid);

    @Insert("Insert into FILES (filename,contenttype,filesize,userid,filedata) VALUES(#{filename},#{contenttype},#{filesize},#{userid},#{filedata})")
    @Options(useGeneratedKeys = true, keyProperty = "fileid")
    int createFile(File file);

    @Delete("Delete from FILES where fileid = #{fileid}")
    int deleteFile(Integer fileid);
}
