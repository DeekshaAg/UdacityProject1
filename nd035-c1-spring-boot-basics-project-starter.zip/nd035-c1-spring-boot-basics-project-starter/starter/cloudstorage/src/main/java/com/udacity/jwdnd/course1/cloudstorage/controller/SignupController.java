package com.udacity.jwdnd.course1.cloudstorage.controller;

import com.udacity.jwdnd.course1.cloudstorage.model.User;
import com.udacity.jwdnd.course1.cloudstorage.services.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SignupController {

    private UserService userService;

    public SignupController(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping(method = RequestMethod.GET, value="/signup")
    public String getSignUpPage(){
        return "signup";
    }

    @RequestMapping(method = RequestMethod.POST, value = "/signup")
    public String signup(@ModelAttribute User user, Model model){
        String signUpError = null;

        try {
            if (!userService.isUsernameAvailable(user.getUsername())) {
                signUpError = "This username already exists.";
            }

            if (signUpError == null) {
                int noOfRowsCreated = userService.createUser(user);
                if (noOfRowsCreated <= 0) {
                    signUpError = "Some Error Occurred while signing up the user.";
                }
            }
        }catch (Exception ex){
            return "error";
        }
        if(signUpError == null){
            model.addAttribute("signUpSuccess", Boolean.TRUE);
            return "login";
        }else{
            model.addAttribute("signUpError" , signUpError);
            return "signup";
        }


    }

}
