package com.udacity.jwdnd.course1.cloudstorage;

import com.udacity.jwdnd.course1.cloudstorage.services.EncryptionService;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;

import java.time.Duration;
import java.util.List;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CloudStorageApplicationTests {

	@LocalServerPort
	private int port;

	private WebDriver driver;

	private SigninPage signinPage;

	private LoginPage loginPage;

	@BeforeAll
	static void beforeAll() {
		WebDriverManager.chromedriver().setup();
	}

	@BeforeEach
	public void beforeEach() {
		this.driver = new ChromeDriver();
		signinPage = new SigninPage(driver);
		loginPage = new LoginPage(driver);
	}

	@AfterEach
	public void afterEach() {
		if (this.driver != null) {
			driver.quit();
		}
	}

	@Test
	public void getLoginPage() {
		driver.get("http://localhost:" + this.port + "/login");
		Assertions.assertEquals("Login", driver.getTitle());
	}

	@Test
	public void doLogin() throws InterruptedException {
		//signup part
		WebDriverWait wait = new WebDriverWait(driver, 30);
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f1","l1","u1","p1");
		Assertions.assertEquals("Login",driver.getTitle());

		//login part
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u1","p1");
		Assertions.assertEquals("Home", driver.getTitle());
	}

	@Test
	public void getSignUpPage(){
		driver.get("http://localhost:"+ this.port + "/signup");
		Assertions.assertEquals("Sign Up", driver.getTitle());
	}

	@Test
	public void getRedirectedToLoginPageIfNotAuthenticated(){
		WebDriverWait wait = new WebDriverWait(driver, 30);
		driver.get("http://localhost:" + this.port+ "/home");
		Assertions.assertEquals("Login",driver.getTitle());
	}

	@Test
	public void doSignup(){
		WebDriverWait wait = new WebDriverWait(driver, 30);
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f2","l2","u2","p2");
		Assertions.assertEquals("Login",driver.getTitle());
	}

	@Test
	public void doLogout(){
		//signup part
		WebDriverWait wait = new WebDriverWait(driver, 30);
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f3","l3","u3","p3");
		Assertions.assertEquals("Login",driver.getTitle());

		//login part
		driver.get("http://localhost:" + this.port + "/login");
		WebElement inputUsername = driver.findElement(By.id("inputUsername"));
		inputUsername.sendKeys("u3");
		WebElement inputPassword = driver.findElement(By.id("inputPassword"));
		inputPassword.sendKeys("p3");
		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		Assertions.assertEquals("Home", driver.getTitle());

		//logout part
		driver.get("http://localhost:" + this.port + "/home");
		WebElement logoutButton = driver.findElement(By.id("logout"));
		logoutButton.click();
		Assertions.assertEquals("Login", driver.getTitle());

		//access homepage after logout
		driver.get("http://localhost:" + this.port + "/home");
		Assertions.assertEquals("Login", driver.getTitle());
	}

	@Test
	public void noteCreationTest() {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;

		//sign in
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f4","l4","u4","p4");
		Assertions.assertEquals("Login",driver.getTitle());

		//login
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u4","p4");
		Assertions.assertEquals("Home", driver.getTitle());

		//added note
		addNote();

		//check for note
		driver.get("http://localhost:" + this.port + "/home");
		WebElement notesTab = driver.findElement(By.id("nav-notes-tab"));
		jse.executeScript("arguments[0].click()", notesTab);
		WebElement notesTable = driver.findElement(By.id("userTable"));
		List<WebElement> notesList = notesTable.findElements(By.tagName("th"));
		Boolean created = false;
		for (int i=0; i < notesList.size(); i++) {
			WebElement element = notesList.get(i);
			if (element.getAttribute("innerHTML").equals("noteTitle")) {
				created = true;
				break;
			}
		}
		Assertions.assertTrue(created);
	}

	@Test
	public void noteUpdationTest() {
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		String newNoteTitle = "new note title";
		//sign in
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f5","l5","u5","p5");
		Assertions.assertEquals("Login",driver.getTitle());

		//login
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u5","p5");
		Assertions.assertEquals("Home", driver.getTitle());

		//added note
		addNote();

		//update note
		driver.get("http://localhost:" + this.port + "/home");
		WebElement notesTab = driver.findElement(By.id("nav-notes-tab"));
		jse.executeScript("arguments[0].click()", notesTab);
		WebElement notesTable = driver.findElement(By.id("userTable"));
		List<WebElement> notesList = notesTable.findElements(By.tagName("td"));
		WebElement editElement = null;
		for (int i = 0; i < notesList.size(); i++) {
			WebElement element = notesList.get(i);
			editElement = element.findElement(By.id("edit"));
			if (editElement != null){
				break;
			}
		}
		wait.until(ExpectedConditions.elementToBeClickable(editElement)).click();
		WebElement notetitle = driver.findElement(By.id("note-title"));
		wait.until(ExpectedConditions.elementToBeClickable(notetitle));
		notetitle.clear();
		notetitle.sendKeys(newNoteTitle);
		WebElement savechanges = driver.findElement(By.id("saveChanges"));
		savechanges.click();
		Assertions.assertEquals("Result", driver.getTitle());

		//check the updated note
		driver.get("http://localhost:" + this.port + "/home");
		notesTab = driver.findElement(By.id("nav-notes-tab"));
		jse.executeScript("arguments[0].click()", notesTab);
		notesTable = driver.findElement(By.id("userTable"));
		notesList = notesTable.findElements(By.tagName("th"));
		Boolean edited = false;
		for (int i = 0; i < notesList.size(); i++) {
			WebElement element = notesList.get(i);
			if (element.getAttribute("innerHTML").equals(newNoteTitle)) {
				edited = true;
				break;
			}
		}
		Assertions.assertTrue(edited);
	}

	@Test
	public void noteDeletionTest() {
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		//sign in
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f6","l6","u6","p6");
		Assertions.assertEquals("Login",driver.getTitle());

		//login
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u6","p6");
		Assertions.assertEquals("Home", driver.getTitle());

		//added note
		addNote();

		// delete note
		driver.get("http://localhost:" + this.port + "/home");
		WebElement notesTab = driver.findElement(By.id("nav-notes-tab"));
		jse.executeScript("arguments[0].click()", notesTab);
		WebElement notesTable = driver.findElement(By.id("userTable"));
		List<WebElement> notesList = notesTable.findElements(By.tagName("td"));
		WebElement deleteElement = null;
		for (int i = 0; i < notesList.size(); i++) {
			WebElement element = notesList.get(i);
			deleteElement = element.findElement(By.id("delete"));
			if (deleteElement != null){
				break;
			}
		}
		wait.until(ExpectedConditions.elementToBeClickable(deleteElement)).click();
		Assertions.assertEquals("Result", driver.getTitle());
	}

	@Test
	public void credentialCreationTest() {
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		//sign in
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f7","l7","u7","p7");
		Assertions.assertEquals("Login",driver.getTitle());

		//login
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u7","p7");
		Assertions.assertEquals("Home", driver.getTitle());

		// add credential
		addCredential();
		//check for credential
		driver.get("http://localhost:" + this.port + "/home");
		WebElement credTab = driver.findElement(By.id("nav-credentials-tab"));
		jse.executeScript("arguments[0].click()", credTab);
		WebElement credsTable = driver.findElement(By.id("credentialTable"));
		List<WebElement> credsList = credsTable.findElements(By.tagName("td"));
		List<WebElement> pwdList = credsTable.findElements(By.id("password-field"));
		Boolean created = false;
		Boolean encrypted = true;
		for (int i=0; i < credsList.size(); i++) {
			WebElement element = credsList.get(i);
			WebElement pwd = credsList.get(i+1);
			if (element.getAttribute("innerHTML").equals("userName")) {
				created = true;
				if(pwd.getAttribute("innerHTML").equals("password")){
					encrypted = false;
				}
				break;
			}
		}

		Assertions.assertTrue(encrypted);
		Assertions.assertTrue(created);
	}

	@Test
	public void credentialUpdationTest() {
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		String newCredUsername = "newUser";
		//sign in
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f8","l8","u8","p8");
		Assertions.assertEquals("Login",driver.getTitle());

		//login
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u8","p8");
		Assertions.assertEquals("Home", driver.getTitle());

		// add credential
		addCredential();

		//update credential
		driver.get("http://localhost:" + this.port + "/home");
		WebElement credTab = driver.findElement(By.id("nav-credentials-tab"));
		jse.executeScript("arguments[0].click()", credTab);
		WebElement credsTable = driver.findElement(By.id("credentialTable"));
		List<WebElement> credsList = credsTable.findElements(By.tagName("td"));
		WebElement editElement = null;
		for (int i = 0; i < credsList.size(); i++) {
			WebElement element = credsList.get(i);
			editElement = element.findElement(By.id("editCreds"));
			if (editElement != null){
				break;
			}
		}
		wait.until(ExpectedConditions.elementToBeClickable(editElement)).click();
		WebElement credUsername = driver.findElement(By.id("credential-username"));
		wait.until(ExpectedConditions.elementToBeClickable(credUsername));
		credUsername.clear();
		credUsername.sendKeys(newCredUsername);
		WebElement savechanges = driver.findElement(By.id("save-credential"));
		savechanges.click();
		Assertions.assertEquals("Result", driver.getTitle());

		//check the updated note
		driver.get("http://localhost:" + this.port + "/home");
		credTab = driver.findElement(By.id("nav-credentials-tab"));
		jse.executeScript("arguments[0].click()", credTab);
		credsTable = driver.findElement(By.id("credentialTable"));
		credsList = credsTable.findElements(By.tagName("td"));
		Boolean edited = false;
		for (int i = 0; i < credsList.size(); i++) {
			WebElement element = credsList.get(i);
			if (element.getAttribute("innerHTML").equals(newCredUsername)) {
				edited = true;
				break;
			}
		}
		Assertions.assertTrue(edited);
	}

	@Test
	public void credentialDeletionTest() {
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		//sign in
		driver.get("http://localhost:" + this.port + "/signup");
		signinPage.doSignin("f9","l9","u9","p9");
		Assertions.assertEquals("Login",driver.getTitle());

		//login
		driver.get("http://localhost:" + this.port + "/login");
		loginPage.doLogin("u9","p9");
		Assertions.assertEquals("Home", driver.getTitle());

		// add credential
		addCredential();

		// delete credential
		driver.get("http://localhost:" + this.port + "/home");
		WebElement credTab = driver.findElement(By.id("nav-credentials-tab"));
		jse.executeScript("arguments[0].click()", credTab);
		WebElement credsTable = driver.findElement(By.id("credentialTable"));
		List<WebElement> credsList = credsTable.findElements(By.tagName("td"));
		WebElement deleteElement = null;
		for (int i = 0; i < credsList.size(); i++) {
			WebElement element = credsList.get(i);
			deleteElement = element.findElement(By.id("delete-cred"));
			if (deleteElement != null){
				break;
			}
		}
		wait.until(ExpectedConditions.elementToBeClickable(deleteElement)).click();
		Assertions.assertEquals("Result", driver.getTitle());
	}

	public void addNote(){
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		WebElement notesTab = driver.findElement(By.id("nav-notes-tab"));
		jse.executeScript("arguments[0].click()", notesTab);
		wait.withTimeout(Duration.ofSeconds(30));
		WebElement newNote = driver.findElement(By.id("newnote"));
		wait.until(ExpectedConditions.elementToBeClickable(newNote)).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.id("note-title"))).sendKeys("noteTitle");
		WebElement notedescription = driver.findElement(By.id("note-description"));
		notedescription.sendKeys("noteDescription");
		WebElement savechanges = driver.findElement(By.id("saveChanges"));
		savechanges.click();
		Assertions.assertEquals("Result", driver.getTitle());
	}

	public void addCredential(){
		WebDriverWait wait = new WebDriverWait (driver, 30);
		JavascriptExecutor jse =(JavascriptExecutor) driver;
		WebElement credTab = driver.findElement(By.id("nav-credentials-tab"));
		jse.executeScript("arguments[0].click()", credTab);
		wait.withTimeout(Duration.ofSeconds(30));
		WebElement newCred = driver.findElement(By.id("newcred"));
		wait.until(ExpectedConditions.elementToBeClickable(newCred)).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.id("credential-url"))).sendKeys("credURL");
		WebElement credUsername = driver.findElement(By.id("credential-username"));
		credUsername.sendKeys("userName");
		WebElement credPassword = driver.findElement(By.id("credential-password"));
		credPassword.sendKeys("password");
		WebElement submit = driver.findElement(By.id("save-credential"));
		submit.click();
		Assertions.assertEquals("Result", driver.getTitle());
	}
}
